package com.corbynx010.android.arduinobt;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.io.InputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private final String TAG = "TAG";
    private final String DEVICE_ADDRESS = "98:D3:81:F9:65:A3";
    private final UUID PORT_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");//Serial Port Service ID
    private BluetoothDevice device;
    private BluetoothSocket socket;
    private InputStream inputStream;
    Button startButton, clearButton, stopButton;
    TextView textView;
    boolean deviceConnected = false;
    private ConnectedThread mConnectedThread;
    boolean stopThread;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startButton = findViewById(R.id.buttonStart);
        clearButton = findViewById(R.id.buttonClear);
        stopButton = findViewById(R.id.buttonStop);
        textView = findViewById(R.id.textView);
        textView.setMovementMethod(new ScrollingMovementMethod());
        setUiEnabled(false);

    }

    public void setUiEnabled(boolean bool) {
        startButton.setEnabled(!bool);
        stopButton.setEnabled(bool);
        textView.setEnabled(bool);

    }

    public boolean BTinit() {
        Log.d(TAG, "BTinit: start");
        boolean found = false;
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Log.d(TAG, "BTinit: btAdapter fail, device doesn't support bt");
            Toast.makeText(getApplicationContext(), "Device doesnt Support Bluetooth", Toast.LENGTH_SHORT).show();
        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableAdapter = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableAdapter, 0);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Set<BluetoothDevice> bondedDevices = bluetoothAdapter.getBondedDevices();
        if (bondedDevices.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please Pair the Device first", Toast.LENGTH_SHORT).show();
            Log.d(TAG, "BTinit: No bonded devices");
        } else {
            for (BluetoothDevice iterator : bondedDevices) {

                Log.d(TAG, "BTinit: Itterator address: " + iterator.toString() + "Device address: " + DEVICE_ADDRESS);
                if (iterator.getAddress().equals(DEVICE_ADDRESS)) {
                    device = iterator;
                    found = true;
                    Log.d(TAG, "BTinit: device " + DEVICE_ADDRESS + "bonded");
                    break;
                }
            }
        }
        return found;
    }


    private boolean BTconnect() {
        Log.d(TAG, "BTconnect: start");
        boolean connected = true;
        BluetoothSocket tmp = null;

        try {
            tmp = device.createInsecureRfcommSocketToServiceRecord(PORT_UUID);
            Log.d(TAG, "BTconnect: rfcommsocket success");
        } catch (IOException e) {
            Log.d(TAG, "BTconnect: rfcommsocket fail");
        }
        socket = tmp;

        try {
            socket.connect();
            Log.d(TAG, "BTconnect: socKet connect success");
        } catch (IOException e) {
            Log.d(TAG, "BTconnect: socket connect fail " + e.getMessage());
            try {
                socket.close();
            } catch (IOException e1) {
            }
            connected = false;
        }
        if (connected) {
            try {
                inputStream = socket.getInputStream();
                Log.d(TAG, "BTconnect: InputStream received");
            } catch (IOException e) {
                e.printStackTrace();
                Log.d(TAG, "BTconnect: InputStream not received " + e.toString());
            }

        }
        return connected;
    }


    public void onClickStart(View view) {
        Log.d(TAG, "onClickStart: start");
        if (BTinit()) {
            Log.d(TAG, "onClickStart: BTinit Success");
            if (BTconnect()) {
                Log.d(TAG, "onClickStart: BTconnect Success");
                setUiEnabled(true);
                deviceConnected = true;
                write("\nConnection Opened!\n");
                Log.d(TAG, "onClickStart: Connection opened");
                mConnectedThread = new ConnectedThread(socket);
                mConnectedThread.start();
            }

        }
    }

    public void onClickStop(View view) throws IOException {
        Log.d(TAG, "onClickStop: start");
        stopThread = true;
        inputStream.close();
        //socket.close();
        setUiEnabled(false);
        deviceConnected = false;
        textView.append("\nConnection Closed!\n");
        Log.d(TAG, "onClickStop: connection closed");
    }

    public void onClickClear(View view) {
        textView.setText("");
    }

    public void write(String string) {
        textView.append(string);
        textView.setMovementMethod(new ScrollingMovementMethod());
        while (textView.canScrollVertically(1)) {
            textView.scrollBy(0, 10);
        }
    }
    /**
     * Finally the ConnectedThread which is responsible for maintaining the BTConnection and
     * receiving incoming data through input stream.
     **/
    class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;

        public ConnectedThread(BluetoothSocket socket) {
            Log.d(TAG, "ConnectedThread: Starting.");
            mmSocket = socket;
            InputStream tmpIn = null;

            try {
                tmpIn = mmSocket.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            mmInStream = tmpIn;
        }

        public void run() {
            byte[] buffer = new byte[1024];  // buffer store for the stream

            int bytes; // bytes returned from read()

            // Keep listening to the InputStream until an exception occurs
            while (true) {
                // Read from the InputStream
                try {
                    bytes = mmInStream.read(buffer);
                    final String incomingMessage = new String(buffer, 0, bytes);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            write(incomingMessage);
                            Log.d(TAG, "InputStream: " + incomingMessage);
                        }});
                } catch (IOException e) {
                    Log.e(TAG, "write: Error reading Input Stream. " + e.getMessage());
                    break;
                }
            }
        }
    }
}